Frontier Float32 surface validation fixture
Seven actual RGBA32F Vulkan maps and seven channel-contribution masks.
32 x 32 synthetic test document with separate fabric and gold-thread layers.
These are test fixtures, not exports of a user document or calibrated physical displacement.
PFM floats are little-endian IEEE-754, bottom row first; RGB files use PF, scalar files use Pf.
